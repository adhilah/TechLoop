﻿using TechLoop.Domain.Enums;

namespace TechLoop.Application.DTOs.SubTopics.Requests;

public class CreateSubTopicRequest
{
    public int TopicId { get; set; }
    public string Title { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string? ImageUrl { get; set; } = string.Empty;
    public string Slug { get; set; } = string.Empty;
    public int Position { get; set; }
}