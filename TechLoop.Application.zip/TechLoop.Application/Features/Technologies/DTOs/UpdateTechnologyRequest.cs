﻿using TechLoop.Domain.Enums;
namespace TechLoop.Application.Features.Technologies.DTOs;

public sealed class UpdateTechnologyRequest
{
    public int CategoryId { get; set; }

    public string Name { get; set; } = string.Empty;

    public string Slug { get; set; } = string.Empty;

    public string? Description { get; set; }

    public string? ImageUrl { get; set; }

    public int Position { get; set; }
}