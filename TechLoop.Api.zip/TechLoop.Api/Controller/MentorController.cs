﻿using TechLoop.Application.Features.Technologies.Commands.CreateTechnology;
using TechLoop.Application.Features.Technologies.DTOs;
using MediatR;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using TechLoop.Application.DTOs.SubTopics.Requests;
using TechLoop.Application.Features.SubTopics.Commands.CreateSubTopic;
using TechLoop.Application.Features.SubTopics.Commands.DeleteSubTopic;
using TechLoop.Application.Features.SubTopics.Commands.UpdateSubTopic;
using TechLoop.Application.Features.SubTopics.DTOs;
using TechLoop.Application.Features.Technologies.Commands.DeleteTechnology;
using TechLoop.Application.Features.Technologies.Commands.UpdateTechnology;
using TechLoop.Application.Features.Topics.Commands.CreateTopic;
using TechLoop.Application.Features.Topics.Commands.DeleteTopic;
using TechLoop.Application.Features.Topics.Commands.UpdateTopic;
using TechLoop.Application.Features.Topics.DTOs;
using TechLoop.Application.DTOs.Questions.Requests;
using TechLoop.Application.Features.Questions.Commands.CreateQuestion;
using TechLoop.Application.Features.Questions.Commands.UpdateQuestion;
using TechLoop.Application.Features.Questions.Commands.DeleteQuestion;
using TechLoop.Application.Features.Questions.Commands.PublishQuestion;
using TechLoop.Application.Features.Questions.DTOs;
using TechLoop.Application.Features.Questions.Queries.GetAllQuestions.Mentor;
using TechLoop.Application.Features.Questions.Queries.GetAllQuestions.Mentor;
using TechLoop.Application.Features.Questions.Queries.GetQuestionById.Mentor;
using TechLoop.Application.Features.SubTopics.Commands.PublishSubTopic;
using TechLoop.Application.Features.Technologies.Commands.PublishTechnology;
using TechLoop.Application.Features.Topics.Commands.PublishTopic;
using TechLoop.Application.Features.Technologies.DTOs;
using TechLoop.Application.Features.Technologies.Queries.GetAllTechnologies.Mentor;
using TechLoop.Application.Features.Technologies.Queries.GetTechnologyById.Mentor;
using TechLoop.Application.Features.Topics.DTOs;
using TechLoop.Application.Features.Topics.Queries.GetAllTopics.Mentor;
using TechLoop.Application.Features.Topics.Queries.GetTopicById.Mentor;
using TechLoop.Application.Features.MCQ.Commands.CreateMcqOption;
using TechLoop.Application.Features.MCQ.Commands.DeleteMcqOption;
using TechLoop.Application.Features.MCQ.Commands.UpdateMcqOption;
using TechLoop.Application.Features.MCQ.DTOs;
using System.Security.Claims;
using TechLoop.Application.Features.MCQ.Queries.GetMcqOptionsById.Mentor;

namespace TechLoop.Api.Controllers;

[Authorize(Policy = "MentorOnly")]
[ApiController]
[Route("mentor")]
public sealed class MentorController : ControllerBase
{
    private readonly IMediator _mediator;

    public MentorController(IMediator mediator)
    {
        _mediator = mediator;
    }

    // Create Technology
    [HttpPost("technologies")]
    public async Task<ActionResult<CreateTechnologyResponse>> CreateTechnology(
        [FromBody] CreateTechnologyRequest request,
        CancellationToken cancellationToken)
    {
        var command = new CreateTechnologyCommand(
            request.CategoryId,
            request.Name,
            request.Description,
            request.Slug,
            request.ImageUrl,
            request.Position);

        var result = await _mediator.Send(command, cancellationToken);

        return Ok(result);
    }


    //update publish
    [HttpPatch("technologies/{id:int}/publish")]
    public async Task<ActionResult<PublishTechnologyResponse>> PublishTechnology(int id,
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(new PublishTechnologyCommand(id), cancellationToken);
        return Ok(result);
    }


    //Update Technology
    [HttpPut("technologies/{id:int}")]
    public async Task<ActionResult<UpdateTechnologyResponse>> UpdateTechnology(
        int id,
        [FromBody] UpdateTechnologyRequest request,
        CancellationToken cancellationToken)
    {
        var command = new UpdateTechnologyCommand(
            id,
            request.CategoryId,
            request.Name,
            request.Description,
            request.Slug,
            request.ImageUrl,
            request.Position);

        var result = await _mediator.Send(command, cancellationToken);

        return Ok(result);
    }


    //Soft Delete Technology
    [HttpDelete("technologies/{id:int}")]
    public async Task<IActionResult> DeleteTechnology(
        int id,
        CancellationToken cancellationToken)
    {
        var command = new DeleteTechnologyCommand(id);

        var result = await _mediator.Send(command, cancellationToken);

        return Ok(result);
    }

    // Get all technologies with all details
    [HttpGet("technologies")]
    public async Task<ActionResult<IEnumerable<MentorTechnologyResponse>>> GetAllTechnologies(
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(new GetAllMentorTechnologiesQuery(), cancellationToken);
        return Ok(result);
    }

    // Get all details of  technology by Id
    [HttpGet("technologies/{id:int}")]
    public async Task<ActionResult<MentorTechnologyResponse>> GetTechnologyById(int id,
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(new GetMentorTechnologyByIdQuery(id), cancellationToken);
        return Ok(result);
    }


    // Create Topic
    [HttpPost("topics")]
    public async Task<ActionResult<CreateTopicResponse>> CreateTopic(
        [FromBody] CreateTopicCommand command,
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(command, cancellationToken);
        return Ok(result);
    }

    // update publish
    [HttpPatch("topics/{id:int}/publish")]
    public async Task<ActionResult<PublishTopicResponse>> PublishTopic(int id, CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(new PublishTopicCommand(id), cancellationToken);
        return Ok(result);
    }

    //Update Topic
    [HttpPut("topics/{id:int}")]
    public async Task<ActionResult<UpdateTopicResponse>> UpdateTopic(int id,
        [FromBody] UpdateTopicRequest request,
        CancellationToken cancellationToken)
    {
        var command = new UpdatedTopicCommand(
            id,
            request.TechnologyId,
            request.Title,
            request.Description,
            request.ImageUrl,
            request.Slug,
            request.Position);

        var result = await _mediator.Send(command, cancellationToken);

        return Ok(result);
    }

    //Soft Delete Topic
    [HttpDelete("topics/{id:int}")]
    public async Task<ActionResult<DeleteTopicResponse>> DeleteTopic(
        int id,
        CancellationToken cancellationToken)
    {
        var command = new DeleteTopicCommand(id);

        var result = await _mediator.Send(command, cancellationToken);

        return Ok(result);
    }

    //GET All Topics
    [HttpGet("topics")]
    public async Task<ActionResult<IEnumerable<MentorTopicResponse>>> GetAllTopics(
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(
            new GetAllMentorTopicsQuery(),
            cancellationToken);

        return Ok(result);
    }

    //GET Topic By Id
    [HttpGet("topics/{id:int}")]
    public async Task<ActionResult<MentorTopicResponse>> GetTopicById(
        int id,
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(
            new GetMentorTopicByIdQuery(id),
            cancellationToken);

        return Ok(result);
    }

    //create subtop
    [HttpPost("subtopics")]
    public async Task<ActionResult<CreateSubTopicResponse>> CreateSubTopic(
        [FromBody] CreateSubTopicRequest request, CancellationToken cancellationToken)
    {
        var command = new CreateSubTopicCommand(
            request.TopicId,
            request.Title,
            request.Description,
            request.ImageUrl,
            request.Slug,
            request.Position);

        var result = await _mediator.Send(command, cancellationToken);

        return Ok(result);
    }

    // update publish
    [HttpPatch("subtopics/{id:int}/publish")]
    public async Task<ActionResult<PublishSubTopicResponse>> PublishSubTopic(int id,
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(new PublishSubTopicCommand(id), cancellationToken);
        return Ok(result);
    }

    // Update Subtopic
    [HttpPut("subtopics/{id:int}")]
    public async Task<ActionResult<UpdateSubTopicResponse>> UpdateSubTopic(int id,
        [FromBody] UpdateSubTopicRequest request, CancellationToken cancellationToken)
    {
        var command = new UpdateSubTopicCommand(
            id,
            request.TopicId,
            request.Title,
            request.Description,
            request.ImageUrl,
            request.Slug,
            request.Position);

        var result = await _mediator.Send(command, cancellationToken);
        return Ok(result);
    }

    // Soft delete Subtopic
    [HttpDelete("subtopics/{id:int}")]
    public async Task<ActionResult<DeleteSubTopicResponse>> DeleteSubTopic(int id, CancellationToken cancellationToken)
    {
        var command = new DeleteSubTopicCommand(id);
        var result = await _mediator.Send(command, cancellationToken);
        return Ok(result);
    }

    // Create Question
    [HttpPost("questions")]
    public async Task<ActionResult<CreateQuestionResponse>> CreateQuestion(
        [FromBody] CreateQuestionRequest request, CancellationToken cancellationToken)
    {
        var command = new CreateQuestionCommand(
            request.SubTopicId,
            request.QuestionType,
            request.Title,
            request.Slug,
            request.Description,
            request.ImageUrl,
            request.Mark,
            request.Hint,
            request.Explanation,
            request.TimeLimitSeconds,
            request.MemoryLimitMb,
            request.Difficulty,
            request.Position);

        var result = await _mediator.Send(command, cancellationToken);
        return Ok(result);
    }

    // update publish
    [HttpPatch("questions/{id:int}/publish")]
    public async Task<ActionResult<PublishQuestionResponse>> PublishQuestion(int id,
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(new PublishQuestionCommand(id), cancellationToken);
        return Ok(result);
    }

// Update Question
    [HttpPut("questions/{id:int}")]
    public async Task<ActionResult<UpdateQuestionResponse>> UpdateQuestion(int id,
        [FromBody] UpdateQuestionRequest request,
        CancellationToken cancellationToken)
    {
        var command = new UpdateQuestionCommand(
            id,
            request.SubTopicId,
            request.QuestionType,
            request.Title,
            request.Slug,
            request.Description,
            request.ImageUrl,
            request.Mark,
            request.Hint,
            request.Explanation,
            request.TimeLimitSeconds,
            request.MemoryLimitMb,
            request.Difficulty,
            request.Position);

        var result = await _mediator.Send(command, cancellationToken);
        return Ok(result);
    }

// Soft Delete Question
    [HttpDelete("questions/{id:int}")]
    public async Task<ActionResult<DeleteQuestionResponse>> DeleteQuestion(int id, CancellationToken cancellationToken)
    {
        var command = new DeleteQuestionCommand(id);
        var result = await _mediator.Send(command, cancellationToken);
        return Ok(result);
    }

    // Get all questions
    [HttpGet("questions")]
    public async Task<ActionResult<IEnumerable<MentorQuestionResponse>>> GetAllQuestions(
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(
            new GetAllMentorQuestionsQuery(),
            cancellationToken);
        return Ok(result);
    }

    // Get question by id
    [HttpGet("questions/{id:int}")]
    public async Task<ActionResult<MentorQuestionResponse>> GetQuestionById(int id, CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(
            new GetMentorQuestionByIdQuery(id),
            cancellationToken);

        return Ok(result);
    }






    //=======================================================================================================


    [HttpPost("questions/{questionId:int}/mcq_options")]
    public async Task<IActionResult> CreateMcqOption(int questionId,
        [FromBody] CreateMcqOptionRequest request, CancellationToken cancellationToken)
    {
        var command = new CreateMcqOptionCommand
        {
            QuestionId = questionId,
            OptionText = request.OptionText,
            IsCorrect = request.IsCorrect,
            Position = request.Position
        };

        var result = await _mediator.Send(command, cancellationToken);
        return Ok(result);
    }

    // Update MCQ Option
    [HttpPut("mcq-options/{id:int}")]
    public async Task<IActionResult> UpdateMcqOption(
        int id,
        [FromBody] UpdateMcqOptionRequest request,
        CancellationToken cancellationToken)
    {
        var command = new UpdateMcqOptionCommand
        {
            Id = id,
            OptionText = request.OptionText,
            IsCorrect = request.IsCorrect,
            Position = request.Position
        };

        var response = await _mediator.Send(command, cancellationToken);

        return Ok(response);
    }

    // Delete MCQ Option
    [HttpDelete("mcq-options/{id:int}")]
    public async Task<IActionResult> DeleteMcqOption(
        int id,
        CancellationToken cancellationToken)
    {
        await _mediator.Send(new DeleteMcqOptionCommand(id), cancellationToken);
        return Ok(new
        {
            Success = true,
            Message = "MCQ option deleted successfully."
        });
    }

    // Get Options By Question
    [HttpGet("questions/{questionId:int}/mcq-options")]
    public async Task<IActionResult> GetMcqOptionsByQuestionId(int questionId, CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(new GetMcqOptionByIdQuery(questionId), cancellationToken);
        return Ok(result);
    }
}