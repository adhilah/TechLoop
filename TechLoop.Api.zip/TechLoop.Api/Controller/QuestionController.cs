﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using TechLoop.Application.Features.MCQ.Queries.GetMcqOptionsById.Learner;
using TechLoop.Application.Features.Questions.DTOs;
using TechLoop.Application.Features.Questions.Queries.GetAllQuestions.Learner;
using TechLoop.Application.Features.Questions.Queries.GetLearnerQuestionById;
//using TechLoop.Application.Features.Questions.Queries.GetQuestionById.Learner;

namespace TechLoop.Api.Controllers;

[ApiController]
[Route("questions")]
public sealed class QuestionController : ControllerBase
{
    private readonly IMediator _mediator;

    public QuestionController(IMediator mediator)
    {
        _mediator = mediator;
    }

    // Get all questions
    [HttpGet]
    public async Task<ActionResult<IEnumerable<LearnerQuestionResponse>>> GetAllQuestions(
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(
            new GetAllLearnerQuestionsQuery(),
            cancellationToken);

        return Ok(result);
    }

    // Get question by id
    [HttpGet("{id:int}")]
    public async Task<ActionResult<LearnerQuestionResponse>> GetQuestionById(
        int id,
        CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(
            new GetLearnerQuestionByIdQuery(id),
            cancellationToken);

        return Ok(result);
    }
    
    [HttpGet("questions/{questionId:int}/mcq-options")]
    public async Task<IActionResult> GetPublishedMcqOptionsByQuestionId(int questionId, CancellationToken cancellationToken)
    {
        var result = await _mediator.Send(new GetPublishedMcqOptionByIdQuery(questionId), cancellationToken);
        return Ok(result);
    }
}